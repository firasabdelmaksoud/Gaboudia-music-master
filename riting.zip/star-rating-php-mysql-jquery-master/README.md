# star-rating-php-mysql-jquery

Star rating demo using Jquery, PHP and Mysql
